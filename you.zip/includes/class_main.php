<?php
/*======================================================================*\
|| #################################################################### ||
|| #                     Arbb 1.0.0 (beta 1)                          # ||
|| #       All Copyrights are saved Arabian bulletin board team       # ||
|| #                   Copyright � 2006 ArBB Team                     # ||
|| #           ArBB Is Free Bulletin Board and not for sale           # ||
|| #################################################################### ||
\*======================================================================*/
#
#    Language Class started
#
/*
        File name       -> class_main.php
        File Version    -> 1.0.0 Beta 1
        File Programmer -> Thaer
        File type       -> Class
*/

if(!defined('IN_ARBB'))
{
die("<title>ArBB</title>\nYou Cant Access This File !!\n<br>\nArBB");
}

Class arbb_main{

// Start Variables Which will be used here


  var $input=array();


// End Variables Which will be used here :)



              }
//# All Done .. Language Class Finished
?>